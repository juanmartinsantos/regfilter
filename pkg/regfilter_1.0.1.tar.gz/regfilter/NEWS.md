# regfilter 1.0

* This is the first version of the regfilter package.

# regfilter 1.0.1

* Copyright has been updated and additional tests included.