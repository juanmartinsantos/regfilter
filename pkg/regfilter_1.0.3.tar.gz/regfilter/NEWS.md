# regfilter 1.0

* This is the first version of the regfilter package.

# regfilter 1.0.1

* Copyright has been updated and additional tests included.

# regfilter 1.0.2

* Fixed some issues on M1mac and noLD.

# regfilter 1.0.3

* Minor modifications.